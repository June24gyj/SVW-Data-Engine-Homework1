import pandas as pd 

sum = 0

for i in range(2,101,2):
    sum = sum + i

print(sum)