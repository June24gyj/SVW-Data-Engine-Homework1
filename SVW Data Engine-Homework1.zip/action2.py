import pandas as pd

data = {'语文':[68,95,98,90,80], '数学':[65,76,86,88,90], '英语':[30,98,88,77,90]}
result = pd.DataFrame(data, index = ['张飞','关羽','刘备','典韦','许褚'])

print(result)

data = pd.DataFrame(result)
print("科目 | 平均成绩")
print(data.mean())

print("科目 | 最小成绩")
print(data.min())

print("科目| 最大成绩")
print(data.max())

print("科目 | 方差")
print(data.var())

print("科目 | 标准差")
print(data.std())

df_sum = result.sum(axis = 1).sort_values(ascending = False)
print(df_sum)