
import pandas as pd 

result = pd.read_csv('car_complain.csv')
result = result.drop('problem', 1).join(result.problem.str.get_dummies(','))

df_brand = result.groupby(['brand'])['id'].agg(['count']).sort_values('count',ascending = False)
print('品牌投诉总数:\n',df_brand)

df_model = result.groupby(['car_model'])['id'].agg(['count']).sort_values('count',ascending = False)
print('车型投诉总数:\n',df_model)

df_brand_model = result.groupby(['brand','car_model'])['id'].agg(['count']).groupby(['brand']).mean().sort_values('count',ascending = False)
print('品牌车型平均投诉数量：\n',df_brand_model)



